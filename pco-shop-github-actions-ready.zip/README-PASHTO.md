# PCO Shop — GitHub Actions APK

دا ZIP د GitHub Actions لپاره تیار شوی.

## په موبایل کې د APK جوړولو طریقه

1. په GitHub کې نوی Repository جوړ کړه.
2. د دې ZIP ټول فایلونه Repository ته Upload کړه.
3. فایلونه په `main` branch کې Commit کړه.
4. د Repository له پاسه **Actions** خلاص کړه.
5. **Build Android APK** انتخاب کړه.
6. **Run workflow** ووهه.
7. Build چې بشپړ شي، د Workflow په پای کې **Artifacts** برخه کې `pco-shop-debug-apk` ښکاري.
8. هغه ZIP ډاونلوډ کړه او دننه `app-debug.apk` نصب کړه.

## مهم
- د دې Workflow له لارې Debug APK جوړېږي.
- د هر نوي Update لپاره خپل ویب فایلونه بدل کړه او بیا Commit کړه؛ Workflow به نوی APK جوړ کړي.
- د راتلونکو Android امکاناتو لپاره Capacitor plugins کارول کېدای شي، لکه Camera، Files او Notifications.
- د عامه Store لپاره وروسته د release signing/AAB ته اړتیا پیدا کېدای شي.
